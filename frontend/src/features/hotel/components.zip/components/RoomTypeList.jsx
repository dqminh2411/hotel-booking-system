import { useMemo, useState } from 'react';
import EmptyState from '../../../shared/components/EmptyState';
import { formatCurrency } from '../../../shared/utils/formatters';
import RoomTypeCard from './RoomTypeCard';

export default function RoomTypeList({ roomTypes, onViewDetail, onBook }) {
  const [quantities, setQuantities] = useState({});

  function handleQuantityChange(roomTypeId, quantity) {
    setQuantities((prev) => ({ ...prev, [roomTypeId]: quantity }));
  }

  const selections = useMemo(
    () =>
      (roomTypes || [])
        .map((roomType) => ({
          roomTypeId: roomType.roomTypeId,
          name: roomType.name,
          basePricePerNight: roomType.basePricePerNight,
          quantity: quantities[roomType.roomTypeId] || 0,
        }))
        .filter((selection) => selection.quantity > 0),
    [roomTypes, quantities],
  );

  const totalRoomCount = selections.reduce((sum, selection) => sum + selection.quantity, 0);
  const totalPrice = selections.reduce(
    (sum, selection) => sum + selection.basePricePerNight * selection.quantity,
    0,
  );

  function handleBookClick() {
    if (totalRoomCount === 0) return;
    onBook(selections);
  }

  if (!roomTypes || roomTypes.length === 0) {
    return (
      <section>
        <h2 className="text-xl font-semibold text-slate-900">Loại phòng</h2>
        <div className="mt-4">
          <EmptyState
            title="Không có loại phòng phù hợp"
            description="Thử thay đổi ngày nhận phòng, trả phòng hoặc số lượng khách."
          />
        </div>
      </section>
    );
  }

  return (
    <section>
      <h2 className="text-xl font-semibold text-slate-900">Loại phòng</h2>

      <div className="mt-4 grid gap-6 lg:grid-cols-[1fr_320px]">
        <div className="space-y-4">
          {roomTypes.map((roomType) => (
            <RoomTypeCard
              key={roomType.roomTypeId}
              roomType={roomType}
              quantity={quantities[roomType.roomTypeId] || 0}
              onViewDetail={onViewDetail}
              onQuantityChange={handleQuantityChange}
            />
          ))}
        </div>

        <aside className="lg:sticky lg:top-6 lg:h-fit">
          <div className="rounded-lg border border-slate-200 bg-white p-4 shadow-sm">
            <p className="text-sm text-slate-600">
              <span className="text-lg font-bold text-slate-900">{totalRoomCount}</span> phòng đã chọn
            </p>
            <p className="mt-2 text-2xl font-bold text-slate-900">{formatCurrency(totalPrice)}</p>
            <p className="text-xs text-slate-500">Tổng tiền mỗi đêm cho các phòng đã chọn</p>

            <button
              type="button"
              disabled={totalRoomCount === 0}
              onClick={handleBookClick}
              className="accent-button mt-4 w-full"
            >
              Tôi sẽ đặt
            </button>
          </div>
        </aside>
      </div>
    </section>
  );
}